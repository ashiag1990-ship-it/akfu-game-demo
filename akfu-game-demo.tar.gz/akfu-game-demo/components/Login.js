export default function Login({ onLogin }) {
  return (
    <div className="login-screen">
      <div className="neon-bg">
        <div className="stars"></div>
      </div>

      <div className="login-box">
        <h1 className="neon-title">🎬 AKFU</h1>
        <p className="subtitle">Ashia Keyz Film Universe</p>

        <div className="login-form">
          <input type="email" placeholder="Email" className="input-field" />
          <input type="password" placeholder="Password" className="input-field" />

          <button className="play-btn" onClick={onLogin}>
            ENTER GAME →
          </button>

          <p className="signup-text">New here? <span className="neon-text">Create Account</span></p>
        </div>

        <div className="arcade-lights">
          <div className="light light-1"></div>
          <div className="light light-2"></div>
          <div className="light light-3"></div>
        </div>
      </div>
    </div>
  );
}
