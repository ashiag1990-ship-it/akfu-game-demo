import { useState, useEffect } from 'react';

export default function GameWorld({ character, onLogout }) {
  const [position, setPosition] = useState({ x: 50, y: 50 });
  const [direction, setDirection] = useState('down');
  const [npcs, setNpcs] = useState([
    { id: 1, name: 'Director NPC', x: 20, y: 30, emoji: '🎬' },
    { id: 2, name: 'Camera Operator', x: 70, y: 60, emoji: '🎥' },
    { id: 3, name: 'Sound Tech', x: 40, y: 80, emoji: '🎤' }
  ]);
  const [dialog, setDialog] = useState(null);

  useEffect(() => {
    const handleKeyPress = (e) => {
      const step = 5;
      const newPos = { ...position };

      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          newPos.y = Math.max(5, position.y - step);
          setDirection('up');
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          newPos.y = Math.min(95, position.y + step);
          setDirection('down');
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          newPos.x = Math.max(5, position.x - step);
          setDirection('left');
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          newPos.x = Math.min(95, position.x + step);
          setDirection('right');
          break;
        default:
          return;
      }
      setPosition(newPos);
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [position]);

  const handleNpcClick = (npc) => {
    setDialog(`${npc.name}: Welcome to AKFU, ${character.name}! Ready to create some films?`);
    setTimeout(() => setDialog(null), 3000);
  };

  const getRotation = () => {
    const rotations = { up: 0, down: 180, left: 270, right: 90 };
    return rotations[direction] || 0;
  };

  return (
    <div className="game-world-container">
      <div className="neon-bg">
        <div className="stars"></div>
      </div>

      <div className="hud">
        <div className="hud-left">
          <div className="character-card">
            <div className="avatar-small">{character.skin}</div>
            <div className="char-details">
              <p className="name">{character.name}</p>
              <p className="role">{character.outfit}</p>
              <p className="vibe">Vibe: {character.vibe}</p>
              <div className="level-bar">
                <span className="level">LVL {character.level}</span>
                <div className="exp-bar">
                  <div className="exp-fill" style={{ width: '25%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="hud-center">
          <h2 className="world-title">FILM UNIVERSE</h2>
        </div>

        <div className="hud-right">
          <button className="logout-btn" onClick={onLogout}>
            EXIT GAME
          </button>
        </div>
      </div>

      <div className="game-viewport">
        <div className="game-world" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2200%22 height=%2200%22%3E%3Crect fill=%22%231a1a2e%22 width=%2200%22 height=%2200%22/%3E%3Cpath stroke=%2200ff00%22 stroke-width=%220.5%22 d=%22M0 0h200M0 20h200M0 40h200M0 60h200M0 80h200M0 100h200M0 120h200M0 140h200M0 160h200M0 180h200M0 200h200M0 0v200M20 0v200M40 0v200M60 0v200M80 0v200M100 0v200M120 0v200M140 0v200M160 0v200M180 0v200M200 0v200%22 opacity=%220.1%22/%3E%3C/svg%3E")' }}>

          {/* Player Avatar */}
          <div
            className="player-avatar"
            style={{
              left: `${position.x}%`,
              top: `${position.y}%`,
              transform: `translate(-50%, -50%) rotate(${getRotation()}deg)`
            }}
          >
            <div className="avatar-sprite">{character.skin}</div>
            <div className="name-plate">{character.name}</div>
          </div>

          {/* NPCs */}
          {npcs.map(npc => (
            <div
              key={npc.id}
              className="npc-avatar"
              style={{
                left: `${npc.x}%`,
                top: `${npc.y}%`
              }}
              onClick={() => handleNpcClick(npc)}
            >
              <div className="npc-sprite">{npc.emoji}</div>
              <div className="npc-label">{npc.name}</div>
            </div>
          ))}

          {/* Dialog Box */}
          {dialog && (
            <div className="dialog-box">
              <p>{dialog}</p>
            </div>
          )}
        </div>

        <div className="controls-info">
          <p>WASD or Arrow Keys to move · Click NPCs to interact</p>
        </div>
      </div>

      <div className="arcade-lights">
        <div className="light light-1"></div>
        <div className="light light-2"></div>
        <div className="light light-3"></div>
      </div>
    </div>
  );
}
