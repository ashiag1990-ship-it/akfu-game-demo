import { useState } from 'react';

const SKINS = ['🧔', '👨', '🧑', '👱', '🧔‍♀️'];
const OUTFITS = ['🎬 Director', '🎥 Cinematographer', '🎭 Actor', '🎨 Designer', '🎵 Composer'];
const VIBES = ['Cool', 'Artsy', 'Bold', 'Chill', 'Energetic'];

export default function CharacterCreation({ onCreated }) {
  const [name, setName] = useState('');
  const [skin, setSkin] = useState(0);
  const [outfit, setOutfit] = useState(0);
  const [vibe, setVibe] = useState(0);
  const [error, setError] = useState('');

  const handleCreate = () => {
    if (!name.trim()) {
      setError('Enter a name!');
      return;
    }

    const character = {
      name,
      skin: SKINS[skin],
      outfit: OUTFITS[outfit],
      vibe: VIBES[vibe],
      level: 1,
      exp: 0,
      joinedAt: new Date().toISOString()
    };

    onCreated(character);
  };

  return (
    <div className="char-creation">
      <div className="neon-bg">
        <div className="stars"></div>
      </div>

      <div className="creation-box">
        <h1 className="neon-title">Create Your Character</h1>

        <div className="char-preview">
          <div className="avatar-display">
            <div className="avatar-large">{SKINS[skin]}</div>
          </div>
          <div className="char-info">
            <p className="char-name">{name || 'Your Name'}</p>
            <p className="char-role">{OUTFITS[outfit]}</p>
            <p className="char-vibe">Vibe: {VIBES[vibe]}</p>
          </div>
        </div>

        <div className="customization">
          <div className="option-group">
            <label>Character</label>
            <div className="option-buttons">
              {SKINS.map((s, i) => (
                <button
                  key={i}
                  className={`option-btn ${i === skin ? 'active' : ''}`}
                  onClick={() => setSkin(i)}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="option-group">
            <label>Role</label>
            <div className="option-buttons">
              {OUTFITS.map((o, i) => (
                <button
                  key={i}
                  className={`option-btn ${i === outfit ? 'active' : ''}`}
                  onClick={() => setOutfit(i)}
                >
                  {o}
                </button>
              ))}
            </div>
          </div>

          <div className="option-group">
            <label>Vibe</label>
            <div className="option-buttons">
              {VIBES.map((v, i) => (
                <button
                  key={i}
                  className={`option-btn ${i === vibe ? 'active' : ''}`}
                  onClick={() => setVibe(i)}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>

          <input
            type="text"
            maxLength="20"
            placeholder="Your character name..."
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              setError('');
            }}
            className="input-field"
          />

          {error && <p className="error-text">{error}</p>}

          <button className="play-btn" onClick={handleCreate}>
            SPAWN CHARACTER →
          </button>
        </div>
      </div>
    </div>
  );
}
