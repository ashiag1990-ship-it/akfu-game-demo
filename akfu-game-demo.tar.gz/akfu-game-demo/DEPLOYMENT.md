# Deploy AKFU Game Demo to Vercel (Mobile-Friendly Guide)

## Option 1: Deploy via Vercel Website (Easiest for Mobile)

### Step 1: Create a GitHub Repository (on mobile)

1. Open GitHub.com in your mobile browser
2. Log in to your account
3. Tap the **+** icon at the top right → **New repository**
4. Name it: `akfu-game-demo`
5. Set to **Public**
6. Tap **Create repository**
7. Copy the repository URL (looks like: `https://github.com/YOUR_USERNAME/akfu-game-demo`)

### Step 2: Upload Files to GitHub (on mobile)

On your new GitHub repository page:

1. Tap **Add file** → **Upload files**
2. Select all the files from this project:
   - `package.json`
   - `next.config.js`
   - `.gitignore`
   - `README.md`
   - `pages/` folder (all files)
   - `components/` folder (all files)
   - `styles/` folder (all files)

3. Add commit message: "Initial commit: AKFU game demo"
4. Tap **Commit changes**

### Step 3: Deploy to Vercel (on mobile)

1. Open [vercel.com](https://vercel.com) in your mobile browser
2. **Sign in** with GitHub or create a Vercel account (if needed)
3. Click **New Project** button
4. Select your `akfu-game-demo` repository
5. Click **Import**
6. Vercel will auto-detect Next.js
7. Click **Deploy**
8. Wait 2-5 minutes for deployment
9. When done, you'll see your live URL! 🎉

**Your game will be live at something like:** `https://akfu-game-demo-xyz.vercel.app`

---

## What Happens After Deployment

Once deployed:
- Visit the URL on your phone
- Click **ENTER GAME** 
- Create your character with custom skin, role, and vibe
- Enter the game world and move around with arrow keys or WASD
- Click on NPCs to interact

Your character data saves automatically to your browser's storage!

---

## Troubleshooting

**"Build failed" error:**
- Make sure all files are in the correct folder structure
- Check that `package.json` is in the root folder
- Wait a few minutes and retry

**Game loads but styling looks broken:**
- This usually fixes itself after a page refresh
- Clear your browser cache (Settings → Clear browsing data)

**Character doesn't save:**
- Make sure you allow localStorage in your browser
- Try refreshing the page to see if it persists

---

## Optional: Advanced Deployment (if you want more control)

If you want to deploy without GitHub, you can:

1. Create a new project on Vercel
2. Upload the project files directly
3. Or use Vercel CLI (if you have a computer)

But the GitHub method above is easiest on mobile!

---

## Share Your Game!

Once deployed, share the Vercel URL with anyone to let them:
- Create their own character
- Explore the game world
- Experience the arcade aesthetic

The URL is public and shareable!
