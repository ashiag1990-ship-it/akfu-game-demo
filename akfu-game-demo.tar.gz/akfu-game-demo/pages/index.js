import { useState, useEffect } from 'react';
import Login from '../components/Login';
import CharacterCreation from '../components/CharacterCreation';
import GameWorld from '../components/GameWorld';

export default function Home() {
  const [screen, setScreen] = useState('login'); // login, create, game
  const [character, setCharacter] = useState(null);

  useEffect(() => {
    const saved = localStorage.getItem('akfu_character');
    if (saved) {
      setCharacter(JSON.parse(saved));
      setScreen('game');
    }
  }, []);

  const handleLogin = () => {
    setScreen('create');
  };

  const handleCharacterCreated = (char) => {
    setCharacter(char);
    localStorage.setItem('akfu_character', JSON.stringify(char));
    setScreen('game');
  };

  const handleLogout = () => {
    setCharacter(null);
    localStorage.removeItem('akfu_character');
    setScreen('login');
  };

  return (
    <div className="game-container">
      {screen === 'login' && <Login onLogin={handleLogin} />}
      {screen === 'create' && <CharacterCreation onCreated={handleCharacterCreated} />}
      {screen === 'game' && character && <GameWorld character={character} onLogout={handleLogout} />}
    </div>
  );
}
