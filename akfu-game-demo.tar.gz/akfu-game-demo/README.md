# AKFU Game Demo

A game-style platform for the Ashia Keyz Film Universe with arcade aesthetic, character creation, and interactive game world.

## Features

- **Login Screen**: Neon-styled arcade login interface
- **Character Creation**: Create and customize your avatar with:
  - 5 different character skins
  - 5 film roles (Director, Cinematographer, Actor, Designer, Composer)
  - 5 vibes (Cool, Artsy, Bold, Chill, Energetic)
  - Live preview of your character
- **Game World**: Interactive 2D world where you can:
  - Move your avatar around with WASD or Arrow Keys
  - Interact with NPCs
  - Build your character progression

## Tech Stack

- **Framework**: Next.js 14
- **Runtime**: Node.js
- **Styling**: Pure CSS with neon effects
- **Storage**: Browser localStorage for character persistence

## Quick Start

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Production Build

```bash
npm run build
npm start
```

## Deployment to Vercel

This project is optimized for Vercel deployment:

1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your GitHub repository
4. Click "Deploy"
5. Share the generated URL!

## Controls

- **Arrow Keys** or **WASD**: Move your character
- **Click NPCs**: Interact with characters in the world

## File Structure

```
├── pages/
│   ├── _app.js          # Next.js app wrapper
│   └── index.js         # Main game component with state management
├── components/
│   ├── Login.js         # Login screen component
│   ├── CharacterCreation.js  # Character customization component
│   └── GameWorld.js     # Game world and avatar interaction
├── styles/
│   └── globals.css      # All styling including neon effects
├── package.json         # Dependencies
└── next.config.js       # Next.js configuration
```

## Data Persistence

Character data is stored in the browser's localStorage as `akfu_character`. This persists across page refreshes and browser restarts (on the same device/browser).

## Future Enhancements

- 3D avatar models (Babylon.js/Three.js)
- Multiplayer world with real-time avatar positions
- Film production quest system
- Scriptwriting and editing tools
- Collaboration features for film projects
- Achievement/level system
